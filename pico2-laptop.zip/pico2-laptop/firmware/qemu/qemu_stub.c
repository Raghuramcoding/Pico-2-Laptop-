/* TEST ONLY: stands in for the BIOS when the OS runs inside QEMU (mps2-an505,
 * Cortex-M33).  Uses the board's CMSDK UART instead of the RP2350 one. */
#include "os.h"
#include "bios_api.h"

#define REG32(a) (*(volatile uint32_t *)(uintptr_t)(a))
#define QUART 0x40200000u
static void q_putc(char c)
{
    while (REG32(QUART + 4) & 1u) { }
    REG32(QUART) = (uint32_t)(uint8_t)c;
}
static int q_getc(void)
{
    if (!(REG32(QUART + 4) & 2u)) return -1;
    return (int)(REG32(QUART) & 0xffu);
}
static int q_kbd(void) { return -1; }
static uint32_t q_ms(void) { return sys_ticks(); }
static void q_delay(uint32_t ms) { task_sleep(ms); }
static void q_led(int on) { (void)on; }
static void q_lcd_en(int on) { (void)on; }
static void q_fill(int x, int y, int w, int h, uint16_t c) { (void)x; (void)y; (void)w; (void)h; (void)c; }
static void q_row(int r, const char *t, int cc, uint16_t f, uint16_t b) { (void)r; (void)t; (void)cc; (void)f; (void)b; }
static int q_sd_init(void) { return -1; }
static int q_sd_read(uint32_t l, void *b) { (void)l; (void)b; return -1; }
static uint32_t q_blocks(void) { return 0; }
static void q_reboot(void) { kprintf("(reboot requested)\n"); for (;;) { } }

__attribute__((section(".bios_api"), used))
const bios_api_t qemu_bios = {
    .magic = BIOS_MAGIC, .version = BIOS_VERSION, .cpu_hz = 20000000u,
    .putc = q_putc, .getc = q_getc, .kbd_getc = q_kbd, .millis = q_ms, .micros = q_ms,
    .delay_ms = q_delay, .led = q_led, .lcd_enable = q_lcd_en, .lcd_fill = q_fill,
    .lcd_draw_row = q_row, .sd_init = q_sd_init, .sd_read = q_sd_read,
    .sd_blocks = q_blocks, .reboot = q_reboot,
};

void os_early_init(void)
{
    REG32(QUART + 0x10) = 16;       /* baud divider */
    REG32(QUART + 0x08) = 3;        /* TX + RX enable */
}

static volatile uint32_t spin_count;
static void spin_task(void *a) { (void)a; for (;;) spin_count++; }    /* never yields */
static void count_task(void *a)
{
    (void)a;
    for (int i = 1; i <= 5; i++) { task_sleep(100); kprintf("[counter] tick %d (spinner at %u)\n", i, (unsigned)(spin_count > 0)); }
}
void os_extra_tasks(void)
{
    task_create("spin", spin_task, 0, 512);
    task_create("counter", count_task, 0, 1024);
}
